<?php
$conn=mysqli_connect("127.0.0.1","root","root","jkb");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//mysqli_query("set names 'gb2312'");
//mysqli_select_db("jkb",$conn);
?>
