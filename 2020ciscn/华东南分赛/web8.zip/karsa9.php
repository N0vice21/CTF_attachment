{
    "a": "<?php cat`ls`; ?>"
}