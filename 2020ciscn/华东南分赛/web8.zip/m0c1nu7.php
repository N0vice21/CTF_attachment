{
    "a": "<?php phpinfo();?>"
}